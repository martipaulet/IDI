#include "Color.h"

Color::Color(QWidget*parent):QWidget(parent)
{
	ui.setupUi(this);
}