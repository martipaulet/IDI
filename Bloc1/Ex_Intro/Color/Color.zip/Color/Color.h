#include "ui_Color.h"

class Color: public QWidget
{
	Q_OBJECT

public:
	Color(QWidget*Parent=0);

private:
	Ui::Color ui;
};