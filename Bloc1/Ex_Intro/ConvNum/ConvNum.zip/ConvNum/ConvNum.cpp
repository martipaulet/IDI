#include "ConvNum.h"

ConvNum::ConvNum(QWidget*parent):QWidget(parent)
{
	ui.setupUi(this);
}