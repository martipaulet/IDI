#include "ui_ConvNum.h"

class ConvNum: public QWidget
{
	Q_OBJECT

public:
	ConvNum(QWidget*Parent=0);

private:
	Ui::ConvNum ui;
};