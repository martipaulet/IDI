#include "MyLabel.h"
// constructor
MyLabel::MyLabel(QWidget *parent)
    : QLabel(parent) {
    
    // Inicialització d'atributs si cal
}

// implementació slots
void MyLabel::truncarLabel(int n) {
    // Implementació de truncarLabel
    QString str = text();
    str.truncate(n);
    setText(str);//heretat de Qlabel
}
//signals no se implementan pero si se declaran en el .h